package com.app.street_reform.activities;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.app.street_reform.R;
import com.app.street_reform.models.ComplainModel;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.List;
import java.util.Locale;

public class ViewComplainDetailsActivity extends AppCompatActivity{

    DatabaseReference databaseReference;
    ComplainModel complainModel;
    List<String> urlList;
    ViewPager viewPager;
    TabLayout indicator;
    ImageView imgBack;
    TextView tvComplain, tvStatus, tvReportBy, tvDescription, tvSeverity, tvLocation;
    Button btnEdit, btnDelete;
    String key="";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_complain_details);

        Intent intent = getIntent();
        key = intent.getStringExtra("key");

        viewPager = (ViewPager) findViewById(R.id.viewPager);
        indicator = (TabLayout) findViewById(R.id.indicator);

        imgBack = findViewById(R.id.imgBack);
        tvComplain = findViewById(R.id.tvComplain);
        tvStatus = findViewById(R.id.tvStatus);
        tvReportBy = findViewById(R.id.tvReportBy);
        tvDescription = findViewById(R.id.tvDescription);
        tvSeverity = findViewById(R.id.tvSeverity);
        tvLocation = findViewById(R.id.tvLocation);
        btnEdit = findViewById(R.id.btnEdit);
        btnDelete = findViewById(R.id.btnDelete);

        if(key.equals("user")){
            complainModel = MainActivity.model;
        }else if(key.equals("admin")){
            complainModel = ViewComplainsActivity.model;
            btnEdit.setText("Change complain status");
            tvStatus.setVisibility(View.VISIBLE);

            tvStatus.setText("Complain Status: "+complainModel.getStatus());
        }

        databaseReference = FirebaseDatabase.getInstance().getReference("Complaints");

        urlList = complainModel.getUrlList();

        tvComplain.setText("Complain: "+complainModel.getComplainType());
        tvReportBy.setText("Complain by : "+complainModel.getUserName());
        tvDescription.setText(complainModel.getDescription());
        tvSeverity.setText(complainModel.getSeverity());


        Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());

        try {
            List<Address> listAddresses = geocoder.getFromLocation(complainModel.getLatitude(), complainModel.getLongitude(), 1);

            if (listAddresses != null && listAddresses.size() > 0) {
                String address = "";

                if (listAddresses.get(0).getAddressLine(0) != null) {
                    address += listAddresses.get(0).getAddressLine(0);
                    tvLocation.setText(address);
                }else {
                    if (listAddresses.get(0).getThoroughfare() != null) {
                        address += listAddresses.get(0).getThoroughfare() + ", ";
                    }

                    if (listAddresses.get(0).getLocality() != null) {
                        address += listAddresses.get(0).getLocality() + ", ";
                    }

                    if (listAddresses.get(0).getAdminArea() != null) {
                        address += listAddresses.get(0).getAdminArea()+", ";
                    }

                    if (listAddresses.get(0).getCountryName() != null) {
                        address += listAddresses.get(0).getCountryName();
                    }
                    tvLocation.setText(address);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        viewPager.setAdapter(new SliderAdapter(ViewComplainDetailsActivity.this, urlList));
        indicator.setupWithViewPager(viewPager, true);

        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(key.equals("user")){
                    Intent intent = new Intent(getApplicationContext(), ComplainActivity.class);
                    intent.putExtra("key","edit");
                    startActivity(intent);
                }else if(key.equals("admin")){
                    AlertDialog.Builder builder = new AlertDialog.Builder(ViewComplainDetailsActivity.this);
                    builder.setTitle("Select?");
                    builder.setMessage("Do you want to change complain status to Received, Executed or Processed?").setPositiveButton("Received", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            databaseReference.child(complainModel.getId()).child("status").setValue("Received");
                            Toast.makeText(ViewComplainDetailsActivity.this, "Complain status marked as Received", Toast.LENGTH_SHORT).show();
                            tvStatus.setText("Complain Status: Received");
                        }
                    }).setNegativeButton("Executed", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            databaseReference.child(complainModel.getId()).child("status").setValue("Executed");
                            Toast.makeText(ViewComplainDetailsActivity.this, "Complain status marked as Executed", Toast.LENGTH_SHORT).show();
                            tvStatus.setText("Complain Status: Executed");
                        }
                    }).setNeutralButton("Processed", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            databaseReference.child(complainModel.getId()).child("status").setValue("Processed");
                            Toast.makeText(ViewComplainDetailsActivity.this, "Complain status marked as Processed", Toast.LENGTH_SHORT).show();
                            tvStatus.setText("Complain Status: Processed");
                        }
                    });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }

            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ViewComplainDetailsActivity.this);
                builder.setTitle("Confirmation?");
                builder.setMessage("Are you sure to delete/cancel this complain?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        databaseReference.child(complainModel.getId()).removeValue();
                        Toast.makeText(ViewComplainDetailsActivity.this, "Complain deleted successfully", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                        finish();
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

    }

    private ProgressDialog mProgressDialog;
    public void showProgressDialog() {
        if (mProgressDialog == null) {
            mProgressDialog = new ProgressDialog(this);
            mProgressDialog.setMessage("Please wait..");
            mProgressDialog.setCanceledOnTouchOutside(false);
            mProgressDialog.setIndeterminate(true);
        }
        mProgressDialog.show();
    }

    public void hideProgressDialog() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.dismiss();
        }
    }

    public class SliderAdapter extends PagerAdapter {
        private Context context;
        private List<String> urlList;

        public SliderAdapter(Context context, List<String> urlList) {
            this.context = context;
            this.urlList = urlList;
        }

        @Override
        public int getCount() {
            return urlList.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, final int position) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View view = inflater.inflate(R.layout.item_slider, null);

            ImageView imageView = (ImageView) view.findViewById(R.id.imageView);

            final String item = urlList.get(position);
            Picasso.with(context).load(item).placeholder(R.drawable.holder).into(imageView);
            ViewPager viewPager = (ViewPager) container;
            viewPager.addView(view, 0);

            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });

            return view;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            ViewPager viewPager = (ViewPager) container;
            View view = (View) object;
            viewPager.removeView(view);
        }
    }


}