package com.app.street_reform.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.app.street_reform.R;
import com.app.street_reform.models.ComplainModel;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ComplainActivity extends BaseActivity{

    private static final int STORAGE_PERMISSION_CODE = 100;
    private static final int PICK_IMAGE = 102;
    RelativeLayout layoutSelectPic;
    LocationManager locationManager;
    LocationListener locationListener;
    ImageView imgCancel, imgLocation;
    TextView tvComplain, tvUser;
    EditText edtDescription, edtSeverity;
    Button btnPost;
    ProgressDialog mProgressDialog;
    private Uri ImageUri;
    DatabaseReference databaseReference;
    StorageReference mStorageRef ;
    StorageTask mUploadTask;
    public static List<String> urlList;
    RecyclerView recyclerView;
    String userId="", key="";
    ComplainModel complainModel;
    double latitude, longitude;
    boolean locFlag = false;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complain2);

        userId = MainActivity.userId;

        Intent intent = getIntent();
        key = intent.getStringExtra("key");

        mProgressDialog = new ProgressDialog(this);
        databaseReference = FirebaseDatabase.getInstance().getReference("Complaints");
        mStorageRef = FirebaseStorage.getInstance().getReference("Complaints/") ;

        urlList = new ArrayList<>();

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,false);
        recyclerView = findViewById(R.id.recyclerView2) ;
        recyclerView.setHasFixedSize(true); ;
        recyclerView.setLayoutManager(linearLayoutManager);

        layoutSelectPic = findViewById(R.id.layoutSelectPic);
        imgCancel = findViewById(R.id.imgCancel);
        imgLocation = findViewById(R.id.imgLocation);

        tvComplain = findViewById(R.id.tvComplain);
        tvUser = findViewById(R.id.tvUser);
        edtDescription = findViewById(R.id.edtDescription);
        edtSeverity = findViewById(R.id.edtSeverity);
        btnPost = findViewById(R.id.btnPost);


        if(key.equals("new")){
            tvComplain.setText("Complain: "+MainActivity.complainType);
            tvUser.setText("Username: "+MainActivity.userName);
        }else if(key.equals("edit")){
            complainModel = MainActivity.model;

            tvComplain.setText("Complain: "+complainModel.getComplainType());
            tvUser.setText("Username: "+complainModel.getUserName());

            urlList = complainModel.getUrlList();
            abc();

            edtDescription.setText(complainModel.getDescription());
            edtSeverity.setText(complainModel.getSeverity());

            latitude = complainModel.getLatitude();
            longitude = complainModel.getLongitude();
            locFlag = true;

            btnPost.setText("Edit Complain");
        }

        imgCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        imgLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCurrentLocation();
            }
        });
        layoutSelectPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
                        return;
                    }
                }

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(intent, PICK_IMAGE);
            }
        });
        btnPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String description = edtDescription.getText().toString().trim();
                String severity = edtSeverity.getText().toString().trim();

                if(urlList.size()<1){
                    Toast.makeText(getApplicationContext(), "Select any evidence screenshot!!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(description)){
                    edtDescription.setError("Required!");
                    edtDescription.requestFocus();
                    return;
                }
                if(TextUtils.isEmpty(severity)){
                    edtSeverity.setError("Required!");
                    edtSeverity.requestFocus();
                    return;
                }
                if(!locFlag){
                    Toast.makeText(ComplainActivity.this, "Please get your current location first!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(key.equals("new")){
                    String id = databaseReference.push().getKey();

                    String cDate = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault()).format(new Date());
                    String cTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(Calendar.getInstance().getTime());

                    ComplainModel model = new ComplainModel(id,MainActivity.userId,MainActivity.userName,MainActivity.email,urlList,
                            MainActivity.complainType,description,severity,latitude,longitude,cDate, cTime,"Pending");
                    databaseReference.child(id).setValue(model);
                    Toast.makeText(ComplainActivity.this, "Complain submitted successfully", Toast.LENGTH_SHORT).show();
                    recyclerView.setAdapter(null);
                    latitude = 0.0;
                    longitude = 0.0;
                    locFlag = false;

                }else if(key.equals("edit")){
                    String id = complainModel.getId();

                    String cDate = complainModel.getDate();
                    String cTime = complainModel.getTime();

                    latitude = complainModel.getLatitude();
                    longitude = complainModel.getLongitude();

                    ComplainModel model = new ComplainModel(id,complainModel.getUserId(),complainModel.getUserName(),complainModel.getUserEmail(),urlList,
                            complainModel.getComplainType(),description,severity,latitude,longitude,cDate, cTime,complainModel.getStatus());
                    databaseReference.child(id).setValue(model);
                    Toast.makeText(ComplainActivity.this, "Complain edited successfully", Toast.LENGTH_SHORT).show();
                    recyclerView.setAdapter(null);
                    latitude = 0.0;
                    longitude = 0.0;
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == STORAGE_PERMISSION_CODE && grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getApplicationContext(), "Permission Granted", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(intent, PICK_IMAGE);
            } else {
                Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 10000, locationListener);
                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 10000, locationListener);
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK) {

                if (data.getClipData() != null) {
                    int countClipData = data.getClipData().getItemCount();
                    int currentImageSlect = 0;

                    while (currentImageSlect < countClipData) {
                        ImageUri = data.getClipData().getItemAt(currentImageSlect).getUri();
                        recyclerView.setAdapter(null);
                        uploadImages(ImageUri);
                        currentImageSlect = currentImageSlect + 1;
                    }
                } else {
                    ImageUri = data.getData();
                    recyclerView.setAdapter(null);
                    uploadImages(ImageUri);
                }
        }
    }

    private  String getExtension(Uri uri){
        ContentResolver contentResolver = getContentResolver() ;
        MimeTypeMap mime = MimeTypeMap.getSingleton() ;
        return  mime.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private void uploadImages(Uri mImageUri) {
        showProgressDialog("Uploading pictures..");
            final StorageReference fileref = mStorageRef.child(System.currentTimeMillis() + "." + getExtension(mImageUri));
            mUploadTask = fileref.putFile(mImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                    Task<Uri> task = taskSnapshot.getMetadata().getReference().getDownloadUrl();
                    task.addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            try {
                                urlList.add(uri.toString());
                                hideProgressDialog();
                                abc();
                            } catch (Exception ex ){
                                Toast.makeText(getApplicationContext()  , "err" + ex.toString() , Toast.LENGTH_LONG).show();
                                hideProgressDialog();
                            }
                        }
                    });
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(Exception e) {
                    Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    hideProgressDialog();
                }
            }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                    double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                }
            });
    }

    public void abc(){
        recyclerView.setAdapter(null);
        ItemListAdapter imageAdapter = new ItemListAdapter(ComplainActivity.this, urlList);
        recyclerView.setAdapter(imageAdapter);
    }

    public class ItemListAdapter extends RecyclerView.Adapter<ItemListAdapter.ImageViewHolder>{
        private Context mcontext ;
        private List<String> muploadList;

        public ItemListAdapter(Context context , List<String> uploadList ) {
            mcontext = context ;
            muploadList = uploadList ;
        }

        @Override
        public ImageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(mcontext).inflate(R.layout.image_layout , parent , false);
            return (new ImageViewHolder(v));
        }

        @Override
        public void onBindViewHolder(final ImageViewHolder holder, @SuppressLint("RecyclerView") final int position) {

            final String uploadCurrent = muploadList.get(position);

            Picasso.with(mcontext).load(uploadCurrent).placeholder(R.drawable.holder).into(holder.itemPic);
            Picasso.with(mcontext).load(R.drawable.ic_close).placeholder(R.drawable.ic_close).into(holder.imgCancel);

            holder.imgCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    FirebaseStorage mStorage;
                    mStorage = FirebaseStorage.getInstance();
                    StorageReference imgRef = mStorage.getReferenceFromUrl(uploadCurrent);
                    imgRef.delete();
                    urlList.remove(position);
                    //muploadList.remove(uploadCurrent);
                    notifyDataSetChanged();
                }
            });

        }
        @Override
        public int getItemCount() {
            return muploadList.size();
        }

        public class ImageViewHolder extends RecyclerView.ViewHolder{
            public ImageView itemPic;
            public ImageView imgCancel;

            public ImageViewHolder(View itemView) {
                super(itemView);

                itemPic = itemView.findViewById(R.id.img);
                imgCancel = itemView.findViewById(R.id.imgCancel);

            }
        }
    }

    private void getCurrentLocation() {

        mProgressDialog.setTitle("Notify");
        mProgressDialog.setMessage("Getting current location..");
        mProgressDialog.setCanceledOnTouchOutside(false);
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(final Location location) {
                latitude = location.getLatitude();
                longitude = location.getLongitude();

                mProgressDialog.dismiss();
            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) { }
            @Override
            public void onProviderEnabled(String s) { }
            @Override
            public void onProviderDisabled(String s) { }
        };
        if (Build.VERSION.SDK_INT < 23) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 10000, locationListener);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 10000, locationListener);
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 10000, locationListener);
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10000, 10000, locationListener);
            }
        }
    }

}