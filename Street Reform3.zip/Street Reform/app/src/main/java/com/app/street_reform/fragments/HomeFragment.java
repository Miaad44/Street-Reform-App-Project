package com.app.street_reform.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.app.street_reform.R;
import com.app.street_reform.activities.MainActivity;
import com.app.street_reform.activities.ComplainActivity;

public class HomeFragment extends Fragment {
    private ProgressDialog mProgressDialog;
    View view;
    Context context;
    Button btnLighting, btnRoads, btnTrafficLights, btnAbandonedCars, btnBuilding, btnCleanliness;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home, container, false);
        context = container.getContext();

        btnLighting = view.findViewById(R.id.btnLighting);
        btnRoads = view.findViewById(R.id.btnRoads);
        btnTrafficLights = view.findViewById(R.id.btnTrafficLights);
        btnAbandonedCars = view.findViewById(R.id.btnAbandonedCars);
        btnBuilding = view.findViewById(R.id.btnBuilding);
        btnCleanliness = view.findViewById(R.id.btnCleanliness);

        btnLighting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.complainType="Lighting";
                Intent intent = new Intent(context, ComplainActivity.class);
                intent.putExtra("key","new");
                startActivity(intent);
            }
        });
        btnRoads.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.complainType="Roads";
                Intent intent = new Intent(context, ComplainActivity.class);
                intent.putExtra("key","new");
                startActivity(intent);
            }
        });
        btnTrafficLights.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.complainType="Traffic lights";
                Intent intent = new Intent(context, ComplainActivity.class);
                intent.putExtra("key","new");
                startActivity(intent);
            }
        });
        btnAbandonedCars.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.complainType="Abandoned cars";
                Intent intent = new Intent(context, ComplainActivity.class);
                intent.putExtra("key","new");
                startActivity(intent);
            }
        });
        btnBuilding.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.complainType="Building under construction";
                Intent intent = new Intent(context, ComplainActivity.class);
                intent.putExtra("key","new");
                startActivity(intent);
            }
        });
        btnCleanliness.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.complainType="Public Cleanliness";
                Intent intent = new Intent(context, ComplainActivity.class);
                intent.putExtra("key","new");
                startActivity(intent);
            }
        });

        return view;
    }

    public void showProgressDialog() {
        if (mProgressDialog == null) {
            mProgressDialog = new ProgressDialog(context);
            mProgressDialog.setMessage("Loading Data...");
            mProgressDialog.setIndeterminate(true);
        }
        mProgressDialog.show();
    }

    public void hideProgressDialog() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.dismiss();
        }
    }
}
