package com.app.street_reform.activities;

import androidx.annotation.NonNull;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.app.street_reform.R;
import com.app.street_reform.models.UserModelClass;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUpActivity extends BaseActivity {

    EditText edtCivil, signupUsername, signupEmail, signupPassword,signupConfirmPasswod;
    TextView loginRedirectText;
    Button signupBtn;
    DatabaseReference databaseReference;
    String emailPattern="[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    FirebaseAuth mAuth;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        databaseReference = FirebaseDatabase.getInstance().getReference("Users");
        mAuth = FirebaseAuth.getInstance();

        edtCivil = findViewById(R.id.edtCivil);
        signupEmail = findViewById(R.id.edEmail);
        signupUsername = findViewById(R.id.edName);
        signupPassword = findViewById(R.id.edpassword);
        signupConfirmPasswod = findViewById(R.id.ed_Confpass);
        loginRedirectText = findViewById(R.id.tw_account);
        signupBtn = findViewById(R.id.btn_m);

        loginRedirectText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                performSingUp();
            }
        });
    }

    //method
    private void performSingUp() {
        String email = signupEmail.getText().toString().trim();
        String username = signupUsername.getText().toString().trim();
        String civilNo = edtCivil.getText().toString().trim();
        String password = signupPassword.getText().toString().trim();
        String conformPassword = signupConfirmPasswod.getText().toString().trim();

        if(civilNo.isEmpty()||username.isEmpty()){
            edtCivil.setError("Please write your civil number");
            edtCivil.requestFocus();
            return;
        }
        if(!email.matches(emailPattern)){
            signupEmail.setError("Enter correct email");
            signupEmail.requestFocus();
            return;
        }
        if(password.isEmpty()||password.length() < 6 ) {
            signupPassword.setError("Enter proper password");
            signupPassword.requestFocus();
            return;
        }
        if(!password.equals(conformPassword)) {
            signupConfirmPasswod.setError("password not match both filed");
            signupConfirmPasswod.requestFocus();
            return;
        }else {
            showProgressDialog("Plese wait while sign up...");
            mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        saveData(civilNo,username,email,password);
                    }else {
                        hideProgressDialog();
                        Toast.makeText(SignUpActivity.this,"Enter correct email and password"+task.getException(),Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    private void saveData(String civilNo, String userName, String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {

                    final FirebaseUser firebaseUser = mAuth.getCurrentUser();
                    String userId = firebaseUser.getUid();

                    UserModelClass model = new UserModelClass(userId,civilNo,userName,email);
                    databaseReference.child(userId).setValue(model);

                    hideProgressDialog();
                    Toast.makeText(SignUpActivity.this,"Sign up successful",Toast.LENGTH_LONG).show();

                    sendUserToNextActivity();

                }
            }
        });
    }
    private void sendUserToNextActivity() {
        Intent intent=new Intent(SignUpActivity.this, MainActivity.class);
        intent.putExtra("key","custom");
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}